<?php
header("Content-Type: application/json");

$con = mysqli_connect("fdb1029.awardspace.net", "4569530_events", "/t{dMdNM3k6?h0od", "4569530_events");

if (mysqli_connect_errno()) {
    echo json_encode(["success" => false, "message" => "Failed to connect to database: " . mysqli_connect_error()]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $con->prepare("SELECT password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($stored_password_hash);
            $stmt->fetch();

            if (hash_equals($stored_password_hash, hash('sha256', $password))) {
                echo json_encode(["success" => true, "message" => "Login successful."]);
            } else {
                echo json_encode(["success" => false, "message" => "Invalid password."]);
            }
        } else {
            echo json_encode(["success" => false, "message" => "User not found."]);
        }

        $stmt->close();
    } else {
        echo json_encode(["success" => false, "message" => "Please provide a username and password."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
}

$con->close();

?>
