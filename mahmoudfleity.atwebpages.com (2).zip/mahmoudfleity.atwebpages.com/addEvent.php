<?php
header("Content-Type: application/json");

$host = "fdb1029.awardspace.net";
$user = "4569530_events";
$password = "/t{dMdNM3k6?h0od";
$dbname = "4569530_events";

$con = mysqli_connect($host, $user, $password, $dbname);

if (mysqli_connect_errno()) {
    echo json_encode(["error" => "Failed to connect to MySQL: " . mysqli_connect_error()]);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);
$title = $data['title'] ?? '';
$description = $data['description'] ?? '';
$date = $data['date'] ?? '';
$time = $data['time'] ?? '';
$location = $data['location'] ?? '';
$category = $data['category'] ?? '';

error_log("Title: $title");
error_log("Description: $description");
error_log("Date: $date");
error_log("Time: $time");
error_log("Location: $location");
error_log("Category: $category");

if ($title && $description && $date && $time && $location && $category) {
    $sql = "INSERT INTO events (title, description, date, time, location, category)
            VALUES ('$title', '$description', '$date', '$time', '$location', '$category')";
    
    if (mysqli_query($con, $sql)) {
        echo json_encode(["success" => "Event added successfully"]);
    } else {
        echo json_encode(["error" => "Error executing query: " . mysqli_error($con)]);
    }
} else {
    echo json_encode(["error" => "Missing required fields"]);
}

mysqli_close($con);
?>
