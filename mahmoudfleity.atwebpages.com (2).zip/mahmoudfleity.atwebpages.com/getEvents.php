<?php
header("Content-Type: application/json");

$host = "fdb1029.awardspace.net";
$user = "4569530_events";
$password = "/t{dMdNM3k6?h0od";
$dbname = "4569530_events";

$con = mysqli_connect($host, $user, $password, $dbname);

if (mysqli_connect_errno()) {
    echo json_encode(["error" => "Failed to connect to MySQL: " . mysqli_connect_error()]);
    exit();
}

$sql = "SELECT * FROM events";
$result = mysqli_query($con, $sql);

if ($result) {
    $events = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $events[] = $row;
    }
    echo json_encode($events);
} else {
    echo json_encode(["error" => "Error executing query: " . mysqli_error($con)]);
}

mysqli_close($con);
?>
