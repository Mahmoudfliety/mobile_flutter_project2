<?php
header("Content-Type: application/json");

$host = "fdb1029.awardspace.net";
$user = "4569530_events";
$password = "/t{dMdNM3k6?h0od";
$dbname = "4569530_events";

$con = mysqli_connect($host, $user, $password, $dbname);

if (mysqli_connect_errno()) {
    echo json_encode(["error" => "Failed to connect to MySQL: " . mysqli_connect_error()]);
    exit();
}

$event_id = $_POST['event_id'] ?? '';
$title = $_POST['title'] ?? '';
$description = $_POST['description'] ?? '';

if (empty($event_id) || empty($title) || empty($description)) {
    echo json_encode(["error" => "Missing required fields"]);
    exit();
}

$sql = "UPDATE events SET title = ?, description = ? WHERE event_id = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("ssi", $title, $description, $event_id);

if ($stmt->execute()) {
    echo json_encode(["success" => "Event updated successfully"]);
} else {
    echo json_encode(["error" => "Error executing query: " . mysqli_error($con)]);
}

$stmt->close();
mysqli_close($con);
?>
