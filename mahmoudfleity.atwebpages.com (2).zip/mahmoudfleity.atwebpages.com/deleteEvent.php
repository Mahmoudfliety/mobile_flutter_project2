<?php
header("Content-Type: application/json");

$host = "fdb1029.awardspace.net";
$user = "4569530_events";
$password = "/t{dMdNM3k6?h0od";
$dbname = "4569530_events";

$con = mysqli_connect($host, $user, $password, $dbname);

if (mysqli_connect_errno()) {
    echo json_encode(["error" => "Failed to connect to MySQL: " . mysqli_connect_error()]);
    exit();
}

$event_id = isset($_GET['event_id']) ? intval($_GET['event_id']) : 0;

if ($event_id > 0) {
    $sql = "DELETE FROM events WHERE event_id = $event_id";
    if (mysqli_query($con, $sql)) {
        echo json_encode(["success" => "Event deleted successfully"]);
    } else {
        echo json_encode(["error" => "Error executing query: " . mysqli_error($con)]);
    }
} else {
    echo json_encode(["error" => "Invalid or missing event_id parameter"]);
}

mysqli_close($con);
?>
