package com.example.local_event_finder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
