import 'dart:convert' as convert;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String _baseURL = 'mahmoudfleity.atwebpages.com';

class Event {
  final int eventId;
  final String title;
  final String description;
  final String date;
  final String time;
  final String location;
  final String category;

  Event(this.eventId, this.title, this.description, this.date, this.time, this.location, this.category);

  @override
  String toString() {
    return 'Event ID: $eventId\nTitle: $title\nDescription: $description\nDate: $date\nTime: $time\nLocation: $location\nCategory: $category';
  }
}

List<Event> _events = [];
void searchEvent(Function(List<Event> events, String message) update, String query) async {
  try {
    final url = Uri.http(_baseURL, 'searchEvent.php', {'query': query});
    final response = await http.get(url).timeout(const Duration(seconds: 5));

    if (response.statusCode == 200) {
      final jsonResponse = convert.jsonDecode(response.body);

      if (jsonResponse is List && jsonResponse.isNotEmpty) {
        List<Event> events = [];
        for (var row in jsonResponse) {
          Event e = Event(
            int.parse(row['event_id']),
            row['title'],
            row['description'],
            row['date'],
            row['time'],
            row['location'],
            row['category'],
          );
          events.add(e);
        }
        update(events, '');
      } else {
        update([], 'No events found matching your search');
      }
    } else {
      update([], 'Failed to load events. Please try again later.');
    }
  } catch (e) {
    update([], 'Error occurred while searching: $e');
  }
}
void updateEvents(Function(bool success) update) async {
  try {
    final url = Uri.http(_baseURL, 'getEvents.php');
    final response = await http.get(url).timeout(const Duration(seconds: 5));

    _events.clear();

    if (response.statusCode == 200) {
      final jsonResponse = convert.jsonDecode(response.body);

      for (var row in jsonResponse) {
        Event e =  Event(
            int.parse(row['event_id']),
            row['title'],
            row['description'],
            row['date'],
            row['time'],
            row['location'],
            row['category']);
        print('test elias ${row['title']} $e');
        _events.add(e);

      }

      update(true);
    } else {
      update(false);
    }
  } catch (e) {
    update(false);
  }
}


class ShowEvents extends StatelessWidget {
  const ShowEvents({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: _events.length,
      itemBuilder: (context, index) => GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => EventPage(event: _events[index]),
            ),
          );
        },
        child: Card(
          margin: const EdgeInsets.all(10),
          color: index % 2 == 0 ? Colors.amber : Colors.cyan,
          elevation: 5,
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _events[index].title,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(
                  'Date: ${_events[index].date}\nLocation: ${_events[index].location}',
                  style: const TextStyle(fontSize: 14, color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class EventPage extends StatelessWidget {
  final Event event;
  const EventPage({Key? key, required this.event}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(event.title)),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Event ID: ${event.eventId}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text('Title: ${event.title}', style: TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            Text('Description: ${event.description}', style: TextStyle(fontSize: 16)),
            const SizedBox(height: 10),
            Text('Date: ${event.date} | Time: ${event.time}', style: TextStyle(fontSize: 16)),
            const SizedBox(height: 10),
            Text('Location: ${event.location}', style: TextStyle(fontSize: 16)),
            const SizedBox(height: 10),
            Text('Category: ${event.category}', style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
