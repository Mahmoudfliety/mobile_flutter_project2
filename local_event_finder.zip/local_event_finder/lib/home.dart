import 'package:flutter/material.dart';
import 'event.dart';
import 'login.dart';
import 'searchEvent.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool _load = false;

  void update(bool success) {
    setState(() {
      _load = true;
      if (!success) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Failed to load data')));
      }
    });
  }

  @override
  void initState() {
    super.initState();
    updateEvents(update);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.login),
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (context) => const LoginPage()));
            },
          ),actions: [
        IconButton(
          onPressed: !_load ? null : () {
            setState(() {
              _load = false;
              updateEvents(update);
            });
          },
          icon: const Icon(Icons.refresh),
        ),
        IconButton(
          onPressed: () {
            setState(() {
              Navigator.of(context).push(MaterialPageRoute(builder: (context) => const SearchEvent()));
            });
          },
          icon: const Icon(Icons.search),
        ),
      ], title: const Text('All Events'), centerTitle: true),
      body: _load
          ? const ShowEvents()
          : const Center(child: SizedBox(width: 100, height: 100, child: CircularProgressIndicator())),
    );
  }
}
