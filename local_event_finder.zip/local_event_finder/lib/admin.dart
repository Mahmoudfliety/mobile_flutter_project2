import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'package:flutter/material.dart';
import 'addEventPage.dart';
import 'event.dart';

const String _baseURL = 'mahmoudfleity.atwebpages.com';

class AdminPage extends StatefulWidget {
  const AdminPage({Key? key}) : super(key: key);

  @override
  _AdminPageState createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  List<Event> _events = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    updateEvents();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: updateEvents,
          ),
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>  AddEventPage(),
                ),
              );
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _events.isEmpty
          ? const Center(child: Text("No events available"))
          : ListView.builder(
        itemCount: _events.length,
        itemBuilder: (context, index) {
          final event = _events[index];
          return Card(
            margin: const EdgeInsets.all(10),
            child: ListTile(
              title: Text(event.title),
              subtitle: Text(
                  'Date: ${event.date} | Location: ${event.location}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () {
                      _showEditDialog(context, event);
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () {
                      _showDeleteConfirmationDialog(event.eventId);
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _showEditDialog(BuildContext context, Event event) {
    final titleController = TextEditingController(text: event.title);
    final descriptionController =
    TextEditingController(text: event.description);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit Event'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              TextField(
                controller: descriptionController,
                decoration: const InputDecoration(labelText: 'Description'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                editEvent(event.eventId, titleController.text,
                    descriptionController.text);
                Navigator.pop(context);
              },
              child: const Text('Save'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  void editEvent(int eventId, String title, String description) async {
    final url = Uri.http(_baseURL, 'updateEvent.php');

    try {
      final response = await http.post(url, body: {
        'event_id': eventId.toString(),
        'title': title,
        'description': description,
      });

      if (response.statusCode == 200) {
        final responseBody = convert.jsonDecode(response.body);
        if (responseBody['success'] != null) {
          setState(() {
            final index =
            _events.indexWhere((event) => event.eventId == eventId);
            if (index != -1) {
              _events[index] = Event(
                  eventId,
                  title,
                  description,
                  _events[index].date,
                  _events[index].time,
                  _events[index].location,
                  _events[index].category);
            }
          });
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Event updated successfully')));
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Failed to update event')));
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: ${response.statusCode}')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  void _showDeleteConfirmationDialog(int eventId) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Confirm Deletion'),
          content: const Text('Are you sure you want to delete this event?'),
          actions: [
            TextButton(
              onPressed: () {
                deleteEvent(eventId);
                Navigator.pop(context);
              },
              child: const Text('Yes'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('No'),
            ),
          ],
        );
      },
    );
  }

  void deleteEvent(int eventId) async {
    final url =
    Uri.http(_baseURL, 'deleteEvent.php', {'event_id': eventId.toString()});
    try {
      final response = await http.get(url);
      final responseBody = convert.jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (responseBody['success'] != null) {
          setState(() {
            _events.removeWhere((event) => event.eventId == eventId);
          });
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Event deleted successfully')));
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Failed to delete event')));
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: ${responseBody['error']}')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  Future<void> updateEvents() async {
    setState(() {
      _loading = true;
    });

    try {
      final url = Uri.http(_baseURL, 'getEvents.php');
      final response = await http.get(url).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final jsonResponse = convert.jsonDecode(response.body);

        if (jsonResponse is List && jsonResponse.isNotEmpty) {
          _events.clear();
          for (var row in jsonResponse) {
            Event e = Event(
              int.parse(row['event_id']),
              row['title'],
              row['description'],
              row['date'],
              row['time'],
              row['location'],
              row['category'],
            );
            _events.add(e);
          }
        } else {
          setState(() {
            _events.clear();
          });
        }
      } else {
        print("Error fetching events: ${response.statusCode}");
      }
    } catch (e) {
      print("Error loading events: $e");
    }

    setState(() {
      _loading = false;
    });
  }
}
