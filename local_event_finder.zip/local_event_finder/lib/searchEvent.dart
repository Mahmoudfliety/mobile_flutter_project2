import 'package:flutter/material.dart';
import 'event.dart';

class SearchEvent extends StatefulWidget {
  const SearchEvent({super.key});

  @override
  State<SearchEvent> createState() => _SearchEventState();
}

class _SearchEventState extends State<SearchEvent> {
  final TextEditingController _controllerQuery = TextEditingController();
  List<Event> _searchResults = [];
  String _errorText = '';

  @override
  void dispose() {
    _controllerQuery.dispose();
    super.dispose();
  }

  
  void searchEvents() async {
    String query = _controllerQuery.text.trim();
    if (query.isNotEmpty) {
      searchEvent((events, message) {
        setState(() {
          _searchResults = events;
          _errorText = message;
        });
      }, query);
    } else {
      setState(() {
        _errorText = 'Please enter a search query';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search Event'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const SizedBox(height: 10),
            TextField(
              controller: _controllerQuery,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Enter Event Name or Description',
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: searchEvents,
              child: const Text('Find'),
            ),
            const SizedBox(height: 20),
            if (_errorText.isNotEmpty) ...[
              Text(_errorText, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 20),
            if (_searchResults.isNotEmpty) ...[
              Expanded(
                child: ListView.builder(
                  itemCount: _searchResults.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(_searchResults[index].title),
                      subtitle: Text(_searchResults[index].description),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => EventPage(
                              event: _searchResults[index],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
