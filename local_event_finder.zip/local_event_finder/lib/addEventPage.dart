import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AddEventPage extends StatefulWidget {
  @override
  _AddEventPageState createState() => _AddEventPageState();
}

class _AddEventPageState extends State<AddEventPage> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _categoryController = TextEditingController();
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();

  Future<void> _submitEvent() async {
    final title = _titleController.text;
    final description = _descriptionController.text;
    final location = _locationController.text;
    final category = _categoryController.text;
    final date = "${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}"; // Format date
    final time = "${_selectedTime.format(context)}";

    print('Title: $title');
    print('Description: $description');
    print('Date: $date');
    print('Time: $time');
    print('Location: $location');
    print('Category: $category');

    final url = Uri.parse('http://mahmoudfleity.atwebpages.com/addEvent.php');
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        'title': title,
        'description': description,
        'date': date,
        'time': time,
        'location': location,
        'category': category,
      }),
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      if (responseData['success'] != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Event added successfully!')),
        );

        _titleController.clear();
        _descriptionController.clear();
        _locationController.clear();
        _categoryController.clear();

        setState(() {
          _selectedDate = DateTime.now();
          _selectedTime = TimeOfDay.now();
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${responseData['error']}')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Request failed with status: ${response.statusCode}')),
      );
    }
  }

  Future<void> _pickDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2101),
    ) ?? _selectedDate;

    setState(() {
      _selectedDate = picked;
    });
  }

  Future<void> _pickTime(BuildContext context) async {
    final TimeOfDay picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    ) ?? _selectedTime;

    setState(() {
      _selectedTime = picked;
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Event'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: _submitEvent,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Event Title'),
            ),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Event Description'),
            ),
            TextField(
              controller: _locationController,
              decoration: InputDecoration(labelText: 'Event Location'),
            ),
            TextField(
              controller: _categoryController,
              decoration: InputDecoration(labelText: 'Event Category'),
            ),
            ListTile(
              title: Text('Date: ${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}'),
              onTap: () => _pickDate(context),
            ),
            ListTile(
              title: Text('Time: ${_selectedTime.format(context)}'),
              onTap: () => _pickTime(context),
            ),
          ],
        ),
      ),
    );
  }
}
